package ism.view;

import java.util.Scanner;

import ism.entity.Classe;
import ism.entity.Cours;
import ism.entity.Etudiant;
import ism.entity.Session;


public class Main {
    public void display() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("---- Interface Admin ----");
        System.out.println("1. Créer ou lister un cours");
        System.out.println("2. Afficher les classes");
        System.out.println("3. Lister les cours");
        System.out.println("4. Quitter");
        System.out.print("Choisissez une option: ");
        int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:

        }
    }
}

package ism.service;

import java.util.List;
import java.util.Optional;

import ism.entity.Etudiant;
import ism.repositories.EtudiantRepository;

public class EtudiantServiceImpl implements EtudiantServiceImplInt {
    private final EtudiantRepository etudiantRepository;

    public EtudiantServiceImpl(EtudiantRepository etudiantRepository) {
        this.etudiantRepository = etudiantRepository;
    }

    @Override
    public void create(Etudiant etudiant) {
        etudiantRepository.add(etudiant);
    }

    @Override
    public Optional<Etudiant> findById(String id) {
        return etudiantRepository.findById(id);
    }

    @Override
    public List<Etudiant> findAll() {
        return etudiantRepository.getAll();
    }

    @Override
    public void update(Etudiant etudiant) {
        etudiantRepository.update(etudiant);
    }

    @Override
    public void delete(Etudiant etudiant) {
        etudiantRepository.delete(etudiant);
    }
}

package ism.service;

import ism.entity.Etudiant;

import java.util.List;
import java.util.Optional;

public interface EtudiantServiceImplInt {
        void create(Etudiant etudiant);
        Optional<Etudiant> findById(String id);
        List<Etudiant> findAll();
        void update(Etudiant etudiant);
        void delete(Etudiant etudiant);
    
}

package ism.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@EqualsAndHashCode
@Getter
public class Cours {
    private String nomCours;
    private String nomProf;
    private String module;

    private Classe classe;
}

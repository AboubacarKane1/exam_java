package ism.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@EqualsAndHashCode
@Getter

public class Etudiant {
    private String idE;
    private String nomE;
    
    private Classe classe;
}

package ism.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.sql.Date;

@ToString
@Setter
@EqualsAndHashCode
@Getter

public class Session {
    private Date dateS;
    private Date heureD;
    private Date heureF;
    private String salle;
}

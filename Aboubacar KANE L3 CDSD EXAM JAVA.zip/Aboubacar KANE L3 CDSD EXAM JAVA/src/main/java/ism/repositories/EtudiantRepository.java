package ism.repositories;

import ism.entity.Etudiant;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public interface EtudiantRepository extends EtudiantRepositoryInt{
    private List<Etudiant> getEtudiants(){
        return null ;
    };

    public EtudiantRepository(List<Etudiant> etudiants) {
        this.etudiants = etudiants;
    }

    @Override
    public void add(Etudiant etudiant) {
        etudiants.add(etudiant);
    }

    @Override
    public List<Etudiant> getAll() {
        return etudiants;
    }

    @Override
    public Optional<Etudiant> findById(String id) {
        return etudiants.stream()
                .filter(etudiant -> etudiant.getId().equals(id))
                .findFirst();
    }

    public void update(Etudiant etudiant);

    public void delete(Etudiant etudiant);
}

package ism.repositories;

import java.util.List;
import ism.entity.Etudiant;
import ism.repositories.core.Repository;

public interface EtudiantRepositoryInt extends Repository<Etudiant> {
    List<Etudiant> getAvailableEtudiants();
    Etudiant findByID(String id);
}